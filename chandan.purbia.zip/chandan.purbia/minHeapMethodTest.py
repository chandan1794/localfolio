import unittest
from minHeapMethod import add_value, Row, main


class TestMaxHeapMethods(unittest.TestCase):

    def test_add_value_one(self):
        """
        To test the true insertion when heap_size = heap_size_limit - 1
        """
        import _heapq as heapq
        heap = []
        heapq.heapify(heap)
        data = [1, 1]
        heap_size = len(heap)
        heap_size_limit = 2
        heap, heap_size = add_value(heap, data, heap_size, heap_size_limit)

        self.assertEqual(heap_size, len(heap))
        self.assertEqual(heap[0], Row(1, 1))

    def test_add_value_two(self):
        """
        To test the true insertion when heap_size = heap_size_limit
        """
        import _heapq as heapq
        heap = []
        heapq.heapify(heap)
        data = [1, 1]
        heap_size = len(heap)
        heap_size_limit = 1
        heap, heap_size = add_value(heap, data, heap_size, heap_size_limit)

        data = [2, 2]
        heap, heap_size = add_value(heap, data, heap_size, heap_size_limit)

        self.assertEqual(heap_size, 1)
        self.assertEqual(heap[0], Row(2, 2))

    def test_main(self):
        data = [[1, 624],
                [2, 926],
                [3, 961],
                [4, 936],
                [5, 110],
                [6, 706],
                [7, 336],
                [8, 93],
                [9, 289],
                [10, 308]]
        test_file_path = 'test_data.csv'

        import _csv as csv
        with open(test_file_path, mode='w') as test_file:
            csv_writer = csv.writer(test_file, delimiter=' ')
            for data_point in data:
                csv_writer.writerow(data_point)

        X_ = 5
        top_x_ids = main(X_, test_file_path)
        self.assertEqual(top_x_ids, ['6', '2', '3', '4', '8'])


if __name__ == '__main__':
    unittest.main()
