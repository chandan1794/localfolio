"""
Program to select top X ids from a dataset which looks like the following example
1426828011 9
1426828028 350
1426828037 25
1426828056 231
1426828058 109
1426828066 111

Input can be either of the two formats
1. From terminal
2. From a file

Parameter X will be passed from the command line.

Spark SQL uses the most optimized sorting algorithm and which is most likely O(n * log(n)).
But with spark, there are other things too, since it is a distributed framework, the complexity decreases as the
number of resources increases. If we have K jobs/partitions, the complexity changes to O((n * log(n))/K).

Also, Space Complexity decreases the same way.
"""

import argparse

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import desc

# Building the spark session
spark = SparkSession.builder \
    .master("local[2]") \
    .appName("MaxIds") \
    .config("spark.executor.instances", "3") \
    .config("spark.executor.memory", "2g") \
    .config("spark.executor.cores", "1") \
    .getOrCreate()


def get_top_x_ids(df, X):
    """
    Function to get top X IDs from the df
    :param df: input df
    :param X: number of top IDS
    :return: list of top ids (not necessarily ordered)
    """
    data = df.orderBy(desc('value')).limit(X).select("uid").collect()
    return [row['uid'] for row in data]


# Setting the command line argument parser
parser = argparse.ArgumentParser()
parser.add_argument('--X', '-x', help='Top X IDs', default=1, type=int)
parser.add_argument('--absolute_file_path', '-f', help='Absolute path to the file', required=False, type=str)

# Parsing the command line arguments
args = parser.parse_args()
X = args.X
file_path = args.absolute_file_path

# Schema for the input
schema = StructType([
    StructField('uid', IntegerType(), False),
    StructField('value', IntegerType(), False)
])

# Creating an empty dataframe
input_df = spark.createDataFrame([], schema)

# If file path is given create dataframe from that
if file_path is not None:
    input_df = spark\
        .read\
        .format('csv')\
        .option('delimiter', ' ')\
        .option('header', 'false')\
        .schema(schema)\
        .load(file_path)
else:  # If file path is not present create dataframe from the stdin
    print('Please add values')
    while True:
        row = str(input())
        if row not in ["EOF", -1, '']:
            row = spark.sparkContext.parallelize([[int(val) for val in row.split(' ')]])
            print(row)
            new_row = spark.createDataFrame(row, schema)
            input_df = input_df.union(new_row)
        else:
            break

top_x_ids = get_top_x_ids(input_df, X)
print(top_x_ids)
