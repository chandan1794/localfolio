# Top X Elements

Program to select top X ids from a dataset which looks like the following example.

## Assumptions:
Since the problem statement is quite open and a little vague, I have made some assumption around the problem
1. The data has no header
2. All of the data will be in the same format `<id><single white space><value>`
3. `Id` and `value` are `integers`
4. There is no corrupt data, for e.g data with no space, data with multiple space, data having no int etc
5. Value of param `X` is always less than equal to `total rows in the data`

### Data Format
```
1426828011 9
1426828028 350
1426828037 25
1426828056 231
1426828058 109
1426828066 111
```

### Data Insertion Method
1. External data file
    > Note: Please do not add any headers
2. From the terminal
    > To stop inserting values, Insert -1, EOF or press Enter more than once continuously

## Solutions:
My main solution is Min Heap one. The test case are written for that. The pyspark
solution is just to show that, I can solve the same problem with different technologies.

And also this problem is a simple problem, and when something can be done easily one should
not write complex code, because more complex code, more bugs ;)

### Min Heap
1. Run with file

    `$python minHeapMethod.py -f <file_path> -x <param X>`
2. Run without file

    `$python minHeapMethod.py -x <param X>`

### Spark SQL API
1. Run with file

    `$python maxNumId.py -f <file_path> -x <param X>`
2. Run without file

    `$python maxNumId.py -x <param X>`
3. Packages to install

    `$pip install pyspark==2.4.4`

> Note: When running without file, Please enter your data after you see the line "Please add values"

## Unittest
Unittest is only implemented for `Min Heap` solution.

### Run

`python minHeapMethodTest.py`


## Time Took
1. Min Heap: 0.5 hour
2. Spark SQL: 1 hour (Most of the time to search for the time and space complexities
of the functions. I couldn't find the absolute answer but I did found some threads
describing the assumptions around)
3. Unittest: 0.5 hour
4. README.md: 15 minutes
5. Understanding the problem and making the above mentioned assumptions: 1 hour

> Note: The question is a little open ended, and I do have many questions, For now I have
made some assumptions about the problem and the data. Please let me know if you thing anything is missing or incomplete.


