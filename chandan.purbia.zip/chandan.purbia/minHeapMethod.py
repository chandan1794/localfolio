"""
Program to select top X ids from a dataset which looks like the following example
1426828011 9
1426828028 350
1426828037 25
1426828056 231
1426828058 109
1426828066 111

Input can be either of the two formats
1. From terminal
2. From a file

Parameter X will be passed from the command line.

Since the program uses Heap Data Structure, the time complexity to insert an element is O(log(n)),
but in this program is only storing top X element,
And since we will run it for N elements, the final time complexity is
Time Complexity: O(n * log(X))

Space Complexity for the heap is O(n), but in this program is only storing top X element, so the
space complexity is
Space Complexity: O(n * log(X))

"""

import argparse

import _heapq as heapq


class Row(object):
    def __init__(self, _id: int, val: int):
        self._id = _id
        self.val = val

    def __repr__(self):
        return f'Node {self._id}: {self.val}'

    def __lt__(self, other):
        return self.val < other.val

    def __eq__(self, other):
        return (self.val == other.val) and (self._id == other.get_id())

    def get_id(self):
        return self._id


# Setting the command line argument parser
parser = argparse.ArgumentParser()
parser.add_argument('--X', '-x', help='Top X IDs', default=1, type=int)
parser.add_argument('--absolute_file_path', '-f', help='Absolute path to the file', required=False, type=str)


def add_value(heap, data, heap_size, heap_size_limit):
    if len(data) == 2:
        row = Row(data[0], data[1])
        if heap_size < heap_size_limit:
            heapq.heappush(heap, row)
            heap_size = heap_size + 1
        else:
            heapq.heappushpop(heap, row)
    return [heap, heap_size]


def main(X, file_path):
    heap = []
    heapq.heapify(heap)
    heap_size = 0
    if file_path is not None:  # If file path is present
        import _csv as csv
        with open(file_path) as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=' ')
            for data in csv_reader:
                heap, heap_size = add_value(heap, data, heap_size, X)
    else:  # If file path is not present
        print('Please add values')
        while True:
            inp = str(input())
            if inp not in ["EOF", -1, '']:
                inp = [int(val) for val in inp.split(' ')]
                heap, heap_size = add_value(heap, inp, heap_size, X)
            else:
                break

    if len(heap):
        return [row.get_id() for row in heap]
    else:
        return heap


if __name__ == "__main__":
    # Parsing the command line arguments
    args = parser.parse_args()
    X_ = args.X
    file_path_ = args.absolute_file_path

    top_x_ids = main(X_, file_path_)

    if len(top_x_ids):
        print(f"Top {X_} ids (not necessarily ordered or unique)")
        print(top_x_ids)
    else:
        print("No data to show")
